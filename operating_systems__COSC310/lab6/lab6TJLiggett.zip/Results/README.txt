My first trial I used dec.txt as my ascii file. 
I copied it to test.txt using  copyfile. There were no differences.
I then compiled forloop.c from Lab 2 to create for. This was my binary file.
I copied it to test1 using copyfile. There were no differences.
I wrote the od heads for "for" and "test1" to text files and compared them.
There were again no differences. Please see console.png to see a screenshot of console.




For my second trial, I got fancy and used copyfile.c as my ascii file and complied it to create my binary file.
I used copyfile to copy both of these and there were no differences.
Please see inception.png for this inception.