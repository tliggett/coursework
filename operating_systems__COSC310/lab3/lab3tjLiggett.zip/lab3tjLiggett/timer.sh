
time ./seqSum
time ./twoForkSum
time ./fourForkSum
